﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RadiusTest.Radius2;

namespace RadiusTest
{
    class Program
    {
        static void Main(string[] args)
        {
            var radiusClient = new Radius2.radius2Client("http1");

            Radius2.Get_Traffic_by_LoginRequest theTrafficRequest = new Radius2.Get_Traffic_by_LoginRequest();
            theTrafficRequest.Command = new MetaCommand()
            {
                Operation = DbOperation.ExecuteQuery
            };
            theTrafficRequest.Connection = new MetaConnection() { Connection = "*.*" };
            theTrafficRequest.Parameters = new Get_Traffic_by_LoginInputParameters()
            {
                p_Date_Beg = DateTime.Parse("01.12.2014"),
                p_Date_End = DateTime.Parse("01.12.2015"),
                p_Login = "pppoe-049439@prm",
                p_Filial = "423"
            };
            Radius2.Get_Traffic_by_LoginResult theTrafficResult;
            theTrafficResult = radiusClient.Get_Traffic_by_Login(theTrafficRequest);
            Console.WriteLine("Login\t\tCodeText\tBytesIn");
            foreach (var item in theTrafficResult.ResultSet)
            {
                Console.WriteLine(item.login + "\t\t" + item.code_text + "\t" + item.bytes_in);
            }
            Console.ReadLine();
        }
    }
}
